<!DOCTYPE html>
<html lang="PT-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/imc.css">
    <title>IMC - Revisão</title>
</head>
<body>

<header>
  <h1><a href="index.php">Home</a></h1>
</header>

    <div class="resultado">
        <?php
        $nome = $_POST['cxnome'];
        $altura = $_POST['cxaltura'];
        $peso = $_POST['cxpeso'];

        $imc = $peso / ($altura * $altura);

        echo '<h2>Nome: ' . $nome . '</h2>';
        echo '<h2>Resultado do IMC: ' . $imc . '</h2>';

        if ($imc < 17) {
            echo '<p>Muito Abaixo do Peso</p>';
        } else if ($imc < 18.5) {
            echo '<p>Abaixo do Peso</p>';
        } else if ($imc < 25) {
            echo '<p>Peso Ideal</p>';
        } else if ($imc < 30) {
            echo '<p>Sobrepeso</p>';
        } else if ($imc < 35) {
            echo '<p>Obesidade Grau I</p>';
        } else if ($imc < 40) {
            echo '<p>Obesidade Grau II</p>';
        } else {
            echo '<p>Obesidade Grau III</p>';
        }
        ?>
    </div>

    <footer>
        <p>&copy Bruna Luiza Paixão | 3°INFO 2024</p>
    </footer>
    
</body>
</html>
