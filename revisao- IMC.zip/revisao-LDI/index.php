<!DOCTYPE html>
<html lang="PT-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>IMC - Revisão</title>
</head>
<body>

<header>
  <h1><a href="index.php">Home</a></h1>
</header>

<div id="amor">
    <h1>Descubra Seu Caminho para o Bem-Estar: Calcule Seu IMC Agora!</h1>
<p>Seu corpo é um templo que merece cuidado e atenção. Calcule seu Índice de Massa Corporal (IMC) e embarque nesta jornada para uma vida mais saudável. </p>
<p>Conhecendo seu IMC, você estará dando o primeiro passo para tomar decisões conscientes em busca do equilíbrio e bem-estar. </p>
<p>Lembre-se, pequenas mudanças fazem grandes diferenças. Estamos aqui para apoiá-lo nessa jornada de autodescoberta e autocuidado. Vamos lá, comece agora e transforme sua saúde!</p>
</div>
    <div id="corpo">

        <form action="imc.php" method="POST">

        Nome:
        <input type="text" name="cxnome"> <br/>
        
        Altura:
        <input type="text" name="cxaltura"> <br/>
        
        Peso:
        <input type="text" name="cxpeso"> <br/>

        <input type="submit" class="butao" value="IMC">

        </form>
    </div>

    <footer>
        <p>&copy Bruna Luiza Paixão | 3°INFO 2024</p>
    </footer>

</body>
</html>